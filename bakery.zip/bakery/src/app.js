import slider from './scripts/slider.js';
import addClass from './scripts/addClass.js';

import './styles.styl';

slider('.slider');

addClass('.nav-bar');
addClass('.second-page');
